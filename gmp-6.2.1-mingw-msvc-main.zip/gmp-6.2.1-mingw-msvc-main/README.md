# gmp-6.2.1-mingw-msvc
Static build of lib gmp for MinGW64 and MSVC64 for Windows x64
